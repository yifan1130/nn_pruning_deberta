def run1(path, output):
    return "run1_ok"


def run2(path, output):
    return "run2_ok"
